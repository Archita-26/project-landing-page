import { Card } from "./ui/card";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Users, Award, Mail, Linkedin } from "lucide-react";

export function TeamSection() {
  const teamMembers = [
    {
      name: "Kunal Rathore",
      role: "Backend Development",
      initials: "KR",
      color: "bg-blue-600",
      skills: ["Node.js", "MongoDB", "API Design"],
      email: "kunal.rathore@example.com",
      linkedin: "#"
    },
    {
      name: "Mayank Babariya",
      role: "Backend Development",
      initials: "MB",
      color: "bg-purple-600",
      skills: ["Node.js", "Express.js", "Database"],
      email: "mayank.babariya@example.com",
      linkedin: "#"
    },
    {
      name: "Khushi Satav",
      role: "Frontend Development",
      initials: "KS",
      color: "bg-green-600",
      skills: ["React", "JavaScript", "Tailwind"],
      email: "khushi.satav@example.com",
      linkedin: "#"
    },
    {
      name: "Archita Temre",
      role: "UI/UX Design",
      initials: "AT",
      color: "bg-orange-600",
      skills: ["Figma", "Design Systems", "Prototyping"],
      email: "archita.temre@example.com",
      linkedin: "#"
    }
  ];

  const guide = {
    name: "Prof. Ankita Agrawal",
    designation: "Project Guide",
    department: "Department of Information Technology",
    email: "ankitagrawal@acropolis.in",
    initials: "AA",
    color: "bg-indigo-600"
  };

  const externalGuide = {
    name: "Vinay Nebhwani",
    designation: "Manager",
    organization: "Cognizant",
    email: "vinay.nebhwani@cognizant.com",
    initials: "VN",
    color: "bg-teal-600"
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-blue-100 to-purple-100 rounded-full filter blur-3xl opacity-30"></div>
      
      <div className="max-w-7xl mx-auto relative">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 rounded-full px-4 py-2 mb-6">
            <Users className="w-4 h-4" />
            <span className="text-sm">Meet The Team</span>
          </div>
          <h2 className="text-4xl sm:text-5xl mb-4">
            Our
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600"> Team</span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Passionate students working together to revolutionize academic research with AI.
          </p>
        </div>

        {/* Project Guides */}
        <div className="mb-16">
          <div className="flex items-center gap-2 mb-6">
            <Award className="w-5 h-5 text-indigo-600" />
            <h3 className="text-2xl">Project Guides</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {/* Internal Guide */}
            <Card className="p-8 bg-gradient-to-br from-indigo-50 to-white border-indigo-200 shadow-xl">
              <div className="text-center mb-4">
                <p className="text-sm text-indigo-600">Internal Guide</p>
              </div>
              <div className="flex flex-col items-center gap-4">
                <Avatar className="w-20 h-20">
                  <AvatarFallback className={`${guide.color} text-white text-2xl`}>
                    {guide.initials}
                  </AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <h4 className="text-2xl mb-1">{guide.name}</h4>
                  <p className="text-lg text-slate-600 mb-1">{guide.designation}</p>
                  <p className="text-slate-500 mb-3">{guide.department}</p>
                  <a href={`mailto:${guide.email}`} className="text-sm text-blue-600 hover:text-blue-700 inline-flex items-center gap-1">
                    <Mail className="w-3 h-3" />
                    {guide.email}
                  </a>
                </div>
              </div>
            </Card>

            {/* External Guide */}
            <Card className="p-8 bg-gradient-to-br from-teal-50 to-white border-teal-200 shadow-xl">
              <div className="text-center mb-4">
                <p className="text-sm text-teal-600">External Guide</p>
              </div>
              <div className="flex flex-col items-center gap-4">
                <Avatar className="w-20 h-20">
                  <AvatarFallback className={`${externalGuide.color} text-white text-2xl`}>
                    {externalGuide.initials}
                  </AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <h4 className="text-2xl mb-1">{externalGuide.name}</h4>
                  <p className="text-lg text-slate-600 mb-1">{externalGuide.designation}</p>
                  <p className="text-slate-500 mb-3">{externalGuide.organization}</p>
                  <a href={`mailto:${externalGuide.email}`} className="text-sm text-blue-600 hover:text-blue-700 inline-flex items-center gap-1">
                    <Mail className="w-3 h-3" />
                    {externalGuide.email}
                  </a>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Team Members */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-6">
            <Users className="w-5 h-5 text-blue-600" />
            <h3 className="text-2xl">Development Team</h3>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {teamMembers.map((member, index) => (
            <Card 
              key={index} 
              className="p-6 bg-white border-slate-200 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 text-center relative overflow-hidden group"
            >
              {/* Background gradient on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-purple-50 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              
              <div className="relative">
                <Avatar className="w-20 h-20 mx-auto mb-4 ring-4 ring-white shadow-lg">
                  <AvatarFallback className={`${member.color} text-white text-xl`}>
                    {member.initials}
                  </AvatarFallback>
                </Avatar>
                
                <h4 className="text-lg mb-1">{member.name}</h4>
                <p className="text-sm text-slate-600 mb-4">{member.role}</p>
                
                <div className="flex flex-wrap gap-2 justify-center mb-4">
                  {member.skills.map((skill, idx) => (
                    <Badge key={idx} variant="secondary" className="text-xs">
                      {skill}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex justify-center gap-3 pt-4 border-t border-slate-200">
                  <a href={`mailto:${member.email}`} className="w-8 h-8 flex items-center justify-center rounded-full bg-slate-100 hover:bg-blue-600 hover:text-white transition-colors">
                    <Mail className="w-4 h-4" />
                  </a>
                  <a href={member.linkedin} target="_blank" rel="noopener noreferrer" className="w-8 h-8 flex items-center justify-center rounded-full bg-slate-100 hover:bg-blue-600 hover:text-white transition-colors">
                    <Linkedin className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Acknowledgement */}
        <Card className="p-8 bg-gradient-to-br from-slate-900 to-blue-900 text-white shadow-2xl">
          <div className="text-center max-w-3xl mx-auto">
            <h3 className="text-2xl mb-4">Special Thanks</h3>
            <p className="text-blue-200 leading-relaxed">
              We would like to express our gratitude to Acropolis Institute of Technology and Research, the Information Technology Department, 
              and our project guide Prof. Ankita Agrawal for their continuous support and guidance throughout this project. 
              Their expertise and encouragement have been invaluable in bringing this research to life.
            </p>
          </div>
        </Card>
      </div>
    </section>
  );
}
