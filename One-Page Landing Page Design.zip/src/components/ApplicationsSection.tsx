import { Card } from "./ui/card";
import { GraduationCap, Microscope, Building2, BookOpen, CheckCircle } from "lucide-react";

export function ApplicationsSection() {
  const applications = [
    {
      icon: GraduationCap,
      title: "Students",
      description: "Accelerate your academic journey with intelligent research assistance",
      color: "blue",
      gradient: "from-blue-500 to-cyan-500",
      benefits: [
        "Complete literature reviews faster",
        "Understand complex papers easily",
        "Find relevant sources quickly",
        "Improve research quality"
      ]
    },
    {
      icon: Microscope,
      title: "Researchers",
      description: "Stay ahead of the curve with automated research monitoring",
      color: "purple",
      gradient: "from-purple-500 to-pink-500",
      benefits: [
        "Track emerging trends",
        "Discover cross-disciplinary insights",
        "Validate research methodology",
        "Build comprehensive bibliographies"
      ]
    },
    {
      icon: Building2,
      title: "Industry",
      description: "Make data-driven decisions with curated research insights",
      color: "green",
      gradient: "from-green-500 to-emerald-500",
      benefits: [
        "Stay competitive with latest findings",
        "Evidence-based decision making",
        "R&D efficiency improvement",
        "Innovation acceleration"
      ]
    },
    {
      icon: BookOpen,
      title: "Educators",
      description: "Enhance teaching with up-to-date research and materials",
      color: "orange",
      gradient: "from-orange-500 to-amber-500",
      benefits: [
        "Curate course materials efficiently",
        "Share verified sources with students",
        "Track academic developments",
        "Create engaging content"
      ]
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-indigo-100 text-indigo-700 rounded-full px-4 py-2 mb-6">
            <Building2 className="w-4 h-4" />
            <span className="text-sm">Use Cases</span>
          </div>
          <h2 className="text-4xl sm:text-5xl mb-4">
            Built for
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600"> Everyone</span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Whether you're a student, researcher, industry professional, or educator, our AI co-pilot adapts to your needs.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {applications.map((app, index) => (
            <Card 
              key={index} 
              className="p-8 bg-white border-slate-200 shadow-xl hover:shadow-2xl transition-all duration-300 relative overflow-hidden group"
            >
              {/* Background gradient */}
              <div className={`absolute top-0 right-0 w-64 h-64 bg-gradient-to-br ${app.gradient} opacity-5 rounded-full filter blur-3xl group-hover:opacity-10 transition-opacity`}></div>
              
              <div className="relative">
                <div className="flex items-start gap-4 mb-6">
                  <div className={`w-16 h-16 bg-gradient-to-br ${app.gradient} rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform flex-shrink-0`}>
                    <app.icon className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl mb-2">{app.title}</h3>
                    <p className="text-slate-600">{app.description}</p>
                  </div>
                </div>
                
                <div className="space-y-3 pl-20">
                  {app.benefits.map((benefit, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <CheckCircle className={`w-5 h-5 flex-shrink-0 mt-0.5 text-${app.color}-600`} />
                      <span className="text-slate-700">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Statistics */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          <Card className="p-6 text-center bg-gradient-to-br from-blue-50 to-white border-blue-200">
            <div className="text-3xl sm:text-4xl text-blue-600 mb-2">1000+</div>
            <div className="text-sm text-slate-600">Active Students</div>
          </Card>
          <Card className="p-6 text-center bg-gradient-to-br from-purple-50 to-white border-purple-200">
            <div className="text-3xl sm:text-4xl text-purple-600 mb-2">500+</div>
            <div className="text-sm text-slate-600">Research Teams</div>
          </Card>
          <Card className="p-6 text-center bg-gradient-to-br from-green-50 to-white border-green-200">
            <div className="text-3xl sm:text-4xl text-green-600 mb-2">200+</div>
            <div className="text-sm text-slate-600">Organizations</div>
          </Card>
          <Card className="p-6 text-center bg-gradient-to-br from-orange-50 to-white border-orange-200">
            <div className="text-3xl sm:text-4xl text-orange-600 mb-2">150+</div>
            <div className="text-sm text-slate-600">Educational Institutions</div>
          </Card>
        </div>
      </div>
    </section>
  );
}
