import { Card } from "./ui/card";
import { 
  Zap, 
  Clock, 
  Target, 
  BookOpen, 
  TrendingUp, 
  Shield,
  Sparkles,
  Download,
  Share2,
  RefreshCw,
  BarChart3,
  Globe
} from "lucide-react";

export function FeaturesSection() {
  const features = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Process research papers in seconds, not hours",
      color: "from-yellow-500 to-orange-500"
    },
    {
      icon: Target,
      title: "Precision Search",
      description: "AI-powered semantic search for accurate results",
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: BookOpen,
      title: "Smart Summaries",
      description: "Automatic extraction of key findings and insights",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: Shield,
      title: "Credibility Check",
      description: "Validate sources and assess research quality",
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: TrendingUp,
      title: "Citation Analysis",
      description: "Track impact and influence of research papers",
      color: "from-indigo-500 to-blue-500"
    },
    {
      icon: RefreshCw,
      title: "Auto-Update",
      description: "Stay current with latest research in your field",
      color: "from-teal-500 to-cyan-500"
    },
    {
      icon: BarChart3,
      title: "Analytics Dashboard",
      description: "Visualize research trends and patterns",
      color: "from-violet-500 to-purple-500"
    },
    {
      icon: Download,
      title: "Export Reports",
      description: "Generate formatted reports in multiple formats",
      color: "from-rose-500 to-pink-500"
    },
    {
      icon: Share2,
      title: "Collaboration",
      description: "Share insights with your research team",
      color: "from-blue-500 to-indigo-500"
    },
    {
      icon: Globe,
      title: "Multi-Source",
      description: "Access papers from multiple academic databases",
      color: "from-emerald-500 to-green-500"
    },
    {
      icon: Sparkles,
      title: "AI Recommendations",
      description: "Get personalized paper suggestions",
      color: "from-amber-500 to-yellow-500"
    },
    {
      icon: Clock,
      title: "Time Tracking",
      description: "Monitor your research productivity",
      color: "from-cyan-500 to-blue-500"
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-purple-100 to-blue-100 rounded-full filter blur-3xl opacity-30"></div>
      
      <div className="max-w-7xl mx-auto relative">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-purple-100 text-purple-700 rounded-full px-4 py-2 mb-6">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm">Powerful Features</span>
          </div>
          <h2 className="text-4xl sm:text-5xl mb-4">
            Everything You Need for
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600"> Efficient Research</span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Advanced features designed to accelerate your research workflow and boost productivity.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="p-6 bg-white border-slate-200 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 relative overflow-hidden group"
            >
              {/* Gradient background on hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}></div>
              
              <div className="relative">
                <div className={`w-12 h-12 bg-gradient-to-br ${feature.color} rounded-lg flex items-center justify-center mb-4 shadow-md group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                
                <h3 className="text-lg mb-2">{feature.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{feature.description}</p>
              </div>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-br from-blue-900 to-purple-900 rounded-2xl p-8 sm:p-12 text-white shadow-2xl">
            <h3 className="text-2xl sm:text-3xl mb-4">Ready to Transform Your Research?</h3>
            <p className="text-blue-200 mb-8 max-w-2xl mx-auto">
              Join researchers worldwide who are accelerating their work with AI-powered research assistance.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <button className="bg-white text-blue-900 px-8 py-3 rounded-lg hover:bg-blue-50 transition-colors shadow-lg">
                Start Free Trial
              </button>
              <button className="border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white/10 transition-colors">
                View Documentation
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
