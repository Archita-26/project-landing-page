import { Mail, Phone, MapPin, Github, Linkedin, ExternalLink } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* About */}
          <div>
            <h3 className="text-white text-lg mb-4">Research Paper Co-Pilot</h3>
            <p className="text-sm text-slate-400 leading-relaxed mb-4">
              An innovative AI-powered solution for automated research paper analysis and discovery.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-9 h-9 flex items-center justify-center rounded-full bg-slate-800 hover:bg-blue-600 transition-colors">
                <Github className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 flex items-center justify-center rounded-full bg-slate-800 hover:bg-blue-600 transition-colors">
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="hover:text-blue-400 transition-colors flex items-center gap-1">
                  About Project
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition-colors flex items-center gap-1">
                  Documentation
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition-colors flex items-center gap-1">
                  GitHub Repository
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-blue-400 transition-colors flex items-center gap-1">
                  Research Paper
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
            </ul>
          </div>

          {/* College Info */}
          <div>
            <h4 className="text-white mb-4">Institution</h4>
            <div className="space-y-3 text-sm">
              <div>
                <p className="text-white">Acropolis Institute of Technology and Research</p>
                <p className="text-slate-400">Department of Information Technology</p>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 flex-shrink-0 mt-1 text-blue-400" />
                <span className="text-slate-400">
                  Mangliya Square, Indore<br />
                  Madhya Pradesh, India
                </span>
              </div>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white mb-4">Contact Us</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-blue-400" />
                <a href="mailto:project@college.edu" className="hover:text-blue-400 transition-colors">
                  project@college.edu
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-blue-400" />
                <a href="tel:+911234567890" className="hover:text-blue-400 transition-colors">
                  +91 123 456 7890
                </a>
              </li>
              <li className="pt-2">
                <p className="text-slate-400 text-xs">
                  Project Supervisor:<br />
                  Prof. Ankita Agrawal<br />
                  ankitaagrawal@acropolis.in
                </p>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-sm text-slate-400">
            <p>
              © 2024 Research Paper Co-Pilot. Minor Project - Information Technology Department.
            </p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-blue-400 transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-blue-400 transition-colors">Terms of Use</a>
              <a href="#" className="hover:text-blue-400 transition-colors">License</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
