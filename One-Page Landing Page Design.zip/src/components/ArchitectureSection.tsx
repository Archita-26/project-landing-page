import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Code2, Database, Server, Cpu, Layers, Sparkles } from "lucide-react";

export function ArchitectureSection() {
  const technologies = [
    { name: "React", icon: Code2, color: "bg-cyan-500", description: "Frontend Framework" },
    { name: "Node.js", icon: Server, color: "bg-green-500", description: "Backend Runtime" },
    { name: "MongoDB", icon: Database, color: "bg-green-600", description: "Database" },
    { name: "OpenAI API", icon: Sparkles, color: "bg-purple-500", description: "AI Engine" }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 rounded-full px-4 py-2 mb-6">
            <Layers className="w-4 h-4" />
            <span className="text-sm">Technical Architecture</span>
          </div>
          <h2 className="text-4xl sm:text-5xl mb-4">
            System
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600"> Architecture</span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            A modern, scalable architecture built with cutting-edge technologies for optimal performance.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Architecture Diagram */}
          <Card className="p-8 bg-white border-slate-200 shadow-xl">
            <h3 className="text-2xl mb-6 flex items-center gap-2">
              <Cpu className="w-6 h-6 text-blue-600" />
              Architecture Flow Diagram
            </h3>
            <div className="space-y-4">
              {/* Architecture visualization */}
              <div className="bg-gradient-to-br from-slate-900 to-blue-900 rounded-xl p-6 text-white">
                <div className="space-y-4">
                  {/* User Query */}
                  <div className="text-center">
                    <div className="inline-block bg-blue-500 rounded-lg px-6 py-3 shadow-lg text-sm">
                      User Query<br />Natural Language
                    </div>
                  </div>
                  
                  {/* Arrow */}
                  <div className="flex justify-center">
                    <div className="w-0.5 h-6 bg-blue-400"></div>
                  </div>
                  
                  {/* Agent Coordinator and arXiv Database */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="bg-purple-500 rounded-lg px-4 py-3 shadow-lg text-sm">
                        Agent Coordinator
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="bg-cyan-500 rounded-lg px-4 py-3 shadow-lg text-sm">
                        arXiv Database
                      </div>
                    </div>
                  </div>
                  
                  {/* Arrow */}
                  <div className="flex justify-center">
                    <div className="w-0.5 h-6 bg-purple-400"></div>
                  </div>
                  
                  {/* Search Agent with connections */}
                  <div className="relative">
                    <div className="text-center">
                      <div className="inline-block bg-green-500 rounded-lg px-4 py-3 shadow-lg text-sm">
                        🔍 Search Agent<br />
                        <span className="text-xs">Find Papers from arXiv</span>
                      </div>
                    </div>
                    {/* Connection to OpenAI GPT-4 */}
                    <div className="absolute -right-4 top-1/2 transform -translate-y-1/2">
                      <div className="bg-orange-500 rounded px-2 py-1 text-xs shadow whitespace-nowrap">
                        OpenAI GPT-4
                      </div>
                    </div>
                  </div>
                  
                  {/* Arrow */}
                  <div className="flex justify-center">
                    <div className="w-0.5 h-6 bg-green-400"></div>
                  </div>
                  
                  {/* Summary Agent */}
                  <div className="text-center">
                    <div className="inline-block bg-indigo-500 rounded-lg px-4 py-3 shadow-lg text-sm">
                      📄 Summary Agent<br />
                      <span className="text-xs">Read & Summarize Papers</span>
                    </div>
                  </div>
                  
                  {/* Arrow */}
                  <div className="flex justify-center">
                    <div className="w-0.5 h-6 bg-indigo-400"></div>
                  </div>
                  
                  {/* Validation Agent */}
                  <div className="text-center">
                    <div className="inline-block bg-pink-500 rounded-lg px-4 py-3 shadow-lg text-sm">
                      ✅ Validation Agent<br />
                      <span className="text-xs">Check Accuracy & Citations</span>
                    </div>
                  </div>
                  
                  {/* Arrow */}
                  <div className="flex justify-center">
                    <div className="w-0.5 h-6 bg-pink-400"></div>
                  </div>
                  
                  {/* Response */}
                  <div className="text-center">
                    <div className="inline-block bg-yellow-500 rounded-lg px-4 py-3 shadow-lg text-sm">
                      Response to User<br />
                      <span className="text-xs">PDF Export Option</span>
                    </div>
                  </div>
                  
                  {/* Storage Layer */}
                  <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-slate-700">
                    <div className="text-center">
                      <div className="bg-teal-500 rounded px-3 py-2 shadow text-xs">
                        MongoDB<br />Store Data
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="bg-amber-500 rounded px-3 py-2 shadow text-xs">
                        PDF Generation<br />jsPDF
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="text-sm text-slate-600 space-y-2 mt-6">
                <p className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-purple-500 rounded-full mt-1.5 flex-shrink-0"></span>
                  <span>Agent Coordinator manages workflow between all agents</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full mt-1.5 flex-shrink-0"></span>
                  <span>Search Agent retrieves papers from arXiv database</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-indigo-500 rounded-full mt-1.5 flex-shrink-0"></span>
                  <span>Summary Agent processes and summarizes content</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-pink-500 rounded-full mt-1.5 flex-shrink-0"></span>
                  <span>Validation Agent verifies accuracy and citations</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-orange-500 rounded-full mt-1.5 flex-shrink-0"></span>
                  <span>OpenAI GPT-4 powers all AI agent operations</span>
                </p>
              </div>
            </div>
          </Card>

          {/* Technology Stack */}
          <Card className="p-8 bg-white border-slate-200 shadow-xl">
            <h3 className="text-2xl mb-6 flex items-center gap-2">
              <Code2 className="w-6 h-6 text-purple-600" />
              Technology Stack
            </h3>
            <div className="space-y-6">
              {technologies.map((tech, index) => (
                <div key={index} className="flex items-start gap-4 p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
                  <div className={`w-12 h-12 ${tech.color} rounded-lg flex items-center justify-center flex-shrink-0 shadow-md`}>
                    <tech.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-lg mb-1">{tech.name}</h4>
                    <p className="text-sm text-slate-600">{tech.description}</p>
                  </div>
                  <Badge variant="secondary" className="text-xs">Core</Badge>
                </div>
              ))}
              
              <div className="pt-6 border-t border-slate-200">
                <h4 className="text-sm mb-3 text-slate-700">Additional Technologies</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-300">Express.js</Badge>
                  <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-300">Tailwind CSS</Badge>
                  <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-300">Langchain</Badge>
                  <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-300">Axios</Badge>
                  <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-300">JWT Auth</Badge>
                  <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-300">REST API</Badge>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Key Features */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="p-6 bg-gradient-to-br from-blue-50 to-white border-blue-200">
            <h4 className="text-lg mb-2">Scalable</h4>
            <p className="text-sm text-slate-600">Microservices architecture enables horizontal scaling</p>
          </Card>
          <Card className="p-6 bg-gradient-to-br from-purple-50 to-white border-purple-200">
            <h4 className="text-lg mb-2">Modular</h4>
            <p className="text-sm text-slate-600">Independent AI agents can be updated separately</p>
          </Card>
          <Card className="p-6 bg-gradient-to-br from-green-50 to-white border-green-200">
            <h4 className="text-lg mb-2">Secure</h4>
            <p className="text-sm text-slate-600">JWT authentication and encrypted data storage</p>
          </Card>
        </div>
      </div>
    </section>
  );
}
